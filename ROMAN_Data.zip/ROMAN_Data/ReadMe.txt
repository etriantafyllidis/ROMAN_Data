----------------------------------------------------------------------------------------------------------------------------------
						    *  Raw Data Supplementary Files *
----------------------------------------------------------------------------------------------------------------------------------
            Robotic Manipulation Network (ROMAN): Hybrid Hierarchical Learning for Solving Complex Sequential Tasks
----------------------------------------------------------------------------------------------------------------------------------
Please find attached the raw data files from the experiments in .csv format.

In each .csv file, we have indicated which type of experiment we have conducted, compared against, the number of demonstrations
provided to ROMAN where applicable and the Gaussian noise (in cm) on the exteroceptive information.

The data collected from our experiments include:
(1) Which sequence scenario was tested
(2) The success [*] of each sub-task within the sequence of actions
(3) The completion time (in seconds) of each sequence scenario
(4) The overall success of the entire sequence scenario [**]

[*]  Disclaimer for Success:           A value of 0 indicates a failure, value of 1 indicates success
[**] Disclaimer for "Overall" Success: Represents the success rate values in the main manuscript.  

Sincerely the authors,
Eleftherios Triantafyllidis
Fernando Acero
Zhaocheng Liu
Zhibin (Alex) Li

Edinburgh Centre of Robotics
School of Informatics
The University of Edinburgh, UK
The University College London, UK
----------------------------------------------------------------------------------------------------------------------------------